package week3.day2;

import java.util.Map;
import java.util.TreeMap;

public class Problem2Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] number = {2,3,5,6,3,2,1,4,2,1,6,-1};
		//output = 2 ->3 , 3 -> 2
		//Ascending order
		
		Map<Integer, Integer> map = new TreeMap<Integer, Integer>();
		
		for (int i = 0; i < number.length; i++) {
			if(map.containsKey(number[i])) {
				Integer value = map.get(number [i]);
				int newvalue = value+1;
				map.put(number[i], newvalue); 
			}else {
				map.put(number[i], 1);
				
				
			}
		}
			System.out.println(map);
		}
		

}
