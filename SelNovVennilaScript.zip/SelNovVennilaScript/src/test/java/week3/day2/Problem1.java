package week3.day2;

import java.util.HashSet;
import java.util.Set;

public class Problem1 {

	public static void main(String[] args) {
		
		//String input = "yuvaraj";
		//Set<Character> unique = new HashSet<Character>();
		
		//String to charArray
		//char [] charArray = input.toCharArray();
		//for (int i = 0; i < charArray.length; i++) {
		//	unique.add(charArray[i]);
				
			
		//	System.out.println(unique);
		
		
			String input1 = "yuvaraj";
			Set<Character> unique1 = new HashSet<Character>();
			
			//String to charArray
			char [] charArray1 = input1.toCharArray();
			for (int i = 0; i < charArray1.length; i++) {
				if(!unique1.add(charArray1[i])) {
					unique1.remove(charArray1[i]);
				}
					
				}
				System.out.println(unique1);
		}

	}


