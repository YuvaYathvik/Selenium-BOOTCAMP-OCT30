package week3.day2;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "hello";
		char [] charArray = name.toCharArray();		
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		
		for (int i = 0; i < charArray.length; i++) {
			if(map.containsKey(charArray[i])) {
				Integer value = map.get(charArray[i]);
				int newvalue = value+1;
				map.put(charArray[i], newvalue); 
			}else {
				map.put(charArray[i], 1); 
				
				
			}
		}
			System.out.println(map);

	}

}
