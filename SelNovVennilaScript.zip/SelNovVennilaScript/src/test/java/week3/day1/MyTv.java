package week3.day1;

public class MyTv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SamsungTV MyTv = new SamsungTV();
		//MyTv.Changevolume ;
		
		
	}

}
