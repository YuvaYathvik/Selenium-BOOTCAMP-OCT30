package week3.day1;

public class Base {

	public static void main(String[] args) {
		

	}

	public void sum() {
		System.out.println("dup");
	}
}
