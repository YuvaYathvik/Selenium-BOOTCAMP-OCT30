package Week4.day2;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WaitProblem2 {

        @SuppressWarnings("deprecation")
		public static void main(String[] args) {
			// TODO Auto-generated method stub

			WebDriverManager.chromedriver().setup();
		    
			  ChromeDriver driver  = new ChromeDriver();
						    
			  //Handle Notification
			  ChromeOptions options=new ChromeOptions();
			  options.addArguments("--disable-notifications");
					
			  //Application url
			  driver.get("http://leafground.com/pages/alertappear.html");
			  driver.manage().window().maximize();
			  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			  
			  //get element
			 driver.findElement(By.id("alert")).click();
			 
			  //wait for the element to be visible
			 WebDriverWait wait = new WebDriverWait (driver,Duration.ofSeconds(10));
			wait.until(ExpectedConditions.alertIsPresent());//polling 500ms
			  
			  	  
			  //switch to an alert
			// String text = driver.switchTo().alert().getText();
			 //System.out.println(text);
			  
			  //Switch to an alert and click
			  Alert alert = driver.switchTo().alert();
			  String text = alert.getText();
			  System.out.println(text);
			  alert.accept();
			  	  
			  //System.out.println(ele.isDisplayed());
			  


	}

}
