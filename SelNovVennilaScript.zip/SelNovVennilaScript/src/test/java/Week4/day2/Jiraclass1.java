package Week4.day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Jiraclass1 {

	private static final String JavascriptExecutor = null;

	@SuppressWarnings("deprecation")
	@Test (dependsOnMethods = {"Week4.day2.JiraDay2.practise","Week4.day2.SwitchTo.main"})
	public void dependsOn () throws InterruptedException {
		
	
		//Download the chrome driver set the path
		WebDriverManager.chromedriver().setup();
	    
	    ChromeDriver driver  = new ChromeDriver();
	    
	    //Handle Notification
		ChromeOptions options=new ChromeOptions();
        options.addArguments("--disable-notifications");
	    
	    driver.get("https://login.salesforce.com");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");
	    driver.findElement(By.id("password")).sendKeys("SelBootcamp$1234");
	    driver.findElement(By.id("Login")).click();
	    Thread.sleep(10000);
	    
	   driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
	   
	   driver.findElement(By.xpath("//button[text()='View All']")).click();
	   
	   driver.findElement(By.xpath("//p[text()='Sales']")).click();
	   
	   
	   WebElement opportuinity = driver.findElement(By.xpath("(//span[text()='Opportunities'])[1]"));
	   JavascriptExecutor executor = (JavascriptExecutor) driver;
       driver.executeScript("arguments[0].click();", opportuinity);
       
       Thread.sleep(10000);
       
	   driver.findElement(By.xpath("//div[text() = 'New']")).click();
	   driver.findElement(By.xpath("//input[@name = 'Name']")).sendKeys("Salesforce Automation by Yuvaraj S");
	   driver.findElement(By.xpath("//input[@name = 'CloseDate']")).sendKeys("11/13/2021");
	   	
	   WebElement none = driver.findElement(By.xpath("(//div[@role='none']//input)[3]"));
	   JavascriptExecutor executor1 = (JavascriptExecutor) driver;
       driver.executeScript("arguments[0].click();", none);
       
	   driver.findElement(By.xpath("//div[@role = 'listbox']/lightning-base-combobox-item[4]/span[2]")).click();
	   driver.findElement(By.xpath("//li[@class ='slds-button-group-item visible']//button[text() = 'Save']")).click();
	   System.out.println("Salesforce Automation by Yuvaraj S");
	   
	   
	   
	    
	   
		

	}

	private static char[] gettext() {
		// TODO Auto-generated method stub
		return null;
	}

}
