package Week4.day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SwitchTo extends Jiraclass1{


		@SuppressWarnings("deprecation")
		@Ignore
		@Test
		public void main() {
			// TODO Auto-generated method stub

			WebDriverManager.chromedriver().setup();
		    
			  ChromeDriver driver  = new ChromeDriver();
						    
			  //Handle Notification
			  ChromeOptions options=new ChromeOptions();
			  options.addArguments("--disable-notifications");
					
			  //Application url
			  driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm");
			  driver.manage().window().maximize();
			  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			  
			  driver.switchTo().frame(2);
			  String text = driver.findElement(By.id("demo")).getText();
			  System.out.println(text);
			//  driver.findElement(By.xpath("//button[text() = 'Try it']")).click();
			//  Alert alert =driver.switchTo().alert();
			 // System.out.println(alert.getText());
			  driver.switchTo().defaultContent();
			  driver.findElement(By.xpath("//button[text() = 'Try it']")).click();
			  
			
	

	}

}
