package Practise;

import java.awt.List;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class FindTheHighestValue {

	public static void main(String[] args) {
		
		java.util.List<Integer> List = Arrays.asList(0,3,4,50,4,7,6,8,90,100);
		
		int sech = List.stream().sorted(Collections.reverseOrder()).distinct().skip(2).findFirst().get();
		System.out.println(sech);

		Integer secondSmall = List.stream().sorted().distinct().skip(3).findFirst().get();
		System.out.println(secondSmall);
	}

}
