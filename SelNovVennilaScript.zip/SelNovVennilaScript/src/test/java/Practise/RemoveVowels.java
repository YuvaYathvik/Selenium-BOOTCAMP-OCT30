package Practise;

import java.util.Iterator;

public class RemoveVowels {

	public static void main(String[] args) {
		
		
		String s = "testleaf";
		char [] characters = s.toCharArray();
		for (int i = 0; i < characters.length; i++) {
			if (characters [i] == 'a' ||characters [i] == 'e' ||characters [i] == 'i' ||characters [i] == 'o' ||characters [i] == 'u' ) {
				
			}else {
				System.out.print(characters[i]);
			}	
		}
		
        //Method two for remove vowel
		String replace = "Yuvaraj";
		String replaceAll = replace.replaceAll("[aeiou]","");
		System.out.print(replaceAll);
	}
}

