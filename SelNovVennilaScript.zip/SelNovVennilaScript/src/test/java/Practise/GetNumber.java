package Practise;

import com.google.common.primitives.Chars;

public class GetNumber {

	public static void main(String[] args) {
     
		String Uv = "Cognizant placed in top 500 companies in world";
		
		/*	String replaceAll = Uv.replaceAll("[^0-9]", "");
		System.out.print(replaceAll);
	}
	}
*/
		//Method two
     char [] charArray = Uv.toCharArray();
     for (int i = 0; i < charArray.length; i++) {
    	 if (Character.isDigit(charArray[i])) {
    		 System.out.print(charArray[i]);
			
		}
		
	}
		  
  }
  }