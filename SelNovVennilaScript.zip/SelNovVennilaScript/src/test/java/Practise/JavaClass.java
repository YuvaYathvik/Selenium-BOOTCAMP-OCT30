package Practise;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class JavaClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		FileInputStream YS = new FileInputStream ("./src/main/java/Env.properties");
		Properties prop = new Properties();
	    prop.load(YS);
	    prop.getProperty("username");
	    System.out.println(prop.getProperty("username"));
	}

}
