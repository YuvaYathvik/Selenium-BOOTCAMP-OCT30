package Practise;

import java.util.Iterator;

import net.bytebuddy.dynamic.scaffold.MethodRegistry.Handler.ForAbstractMethod;
import week1.day1.Reverse;

public class StringSize {

	public static void main(String[] args) {
	
		String company = "Google is best company";
		
		String str = new String ("Google");
		int length = company.length();
		System.out.println(length);
			
		//covert to charArray
		char[] charArray = company.toCharArray();
		System.out.println(charArray);
		
		//covert to lowecase
		String lowerCase = company.toLowerCase();
		System.out.println(lowerCase);
		
		//covert to uppercase
		String upperCase = company.toUpperCase();
		System.out.println(upperCase);
		
		//check if the substring exist
		System.out.println(company.contains("oo"));
		
		//check if the string end with
		System.out.println(company.endsWith("gle"));
		System.out.println(company.startsWith("Goo"));
		
		//find out index of the character
		System.out.println(company.indexOf("o"));
		System.out.println(company.lastIndexOf("l"));
		
		//String split
		String [] split = company.split("");
		System.out.println(split.length);

		//find occurance
		
		String Dev = "cognizaant";
		char search = 'a';
		int Count = 0;
		
		char [] characters = Dev.toCharArray();
		for (int i = 0; i < characters.length; i++) {
			if (characters [i] == search) {
				Count++;
			}
				
			}
			System.out.println(Count);
			
		//find the first duplicate character. if there is no duplicate, print as no dups found!
		String Uv = "testleaf";
		boolean foundDup = 	false;
		
		char [] characters1 = Uv.toCharArray();
		for (int i = 0; i < characters1.length; i++) {
			for (int j = i+1; j < characters1.length; j++) {
				if (characters1 [i] == characters1 [j]) {
					System.out.println("this is duplicate: "+characters1[i]);
					foundDup = true;
					break;
				}
				
			}
				if (foundDup) 
					break;
					
				}
		
	//What character resides in this index?
		System.out.println(company.charAt(company.length()-1));
		
	//reverse string
		for (int i = 0; i <=10;i++) {
		System.out.println(i);
		
		}

		for (int j = 10; j > 0; j--) {
			System.out.println(j);
		}
		}
	
	

		
	
	}
	
	

