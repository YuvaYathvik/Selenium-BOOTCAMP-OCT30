package Practise;

import java.util.Arrays;

public class FindMissingNumber1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int [] nums = {2,3,4,6,7,8};
		Arrays.sort(nums);
		for (int i = 0; i < nums.length; i++) {
			if (nums [i]+1 != nums [i+1]) {
				System.out.println(nums[i]+1);
				break;
					
				}
			}
	}		
}
		

