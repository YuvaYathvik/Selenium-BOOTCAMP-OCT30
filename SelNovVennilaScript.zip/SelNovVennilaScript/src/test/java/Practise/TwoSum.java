package Practise;

public class TwoSum {

	public static void main(String[] args) {

		int [] sum = {2,4,5,6};
		int k = 6;
		boolean bmatch = false;
		
		
		for (int i = 0; i < sum.length; i++) {
			for (int j = i+1;j< sum.length; j++){	
				if (sum [i] + sum [j] == k) {
					bmatch = true;
					System.out.println("true");
					break;
					
				}
			}
				if (bmatch) {
					break;
					
				}
			
			if(!bmatch);
			System.out.println("false");
			
			
		}
		

	}
}
