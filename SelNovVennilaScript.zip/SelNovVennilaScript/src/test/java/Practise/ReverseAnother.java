package Practise;

import java.util.Iterator;

public class ReverseAnother {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 //String reverse
		String rev = "Yuvaraj";
		
		String [] w = rev.split("");
		for(int i = rev.length()-1; i>=0; i--) {
			System.out.print(w[i]+"");
	}
		
			
		}
	
	
	}
	

