package week1.day2;

public class SwitchOnTV {

	public void SwitchOn(boolean bOff) {
		
		if(bOff == true) {
			System.out.println("Switch On TV");
		} else {
			System.out.println("Switch oF Tv");
		}

		public String getPhonebrand (String PhoneType) {
			if(PhoneType.equals ("Android")) 
				retrun "One plus 5";
			else
				retrun "I phone";
	}

}

	public static void  main (String[] argu) {
		//How to call a method from a main method
		//Step 1 - create a object of the class
		//ClassName ref = new classname
SwitchOnTV call = new SwitchOnTV ();
		
		//Call using that reference
		//Step 2 - ref.method
		
		
		
		AndroidXPhone Phone = new AndroidXPhone();
		
		String ph = Phone.getPhonebrand ("Android");
		System.out.println(ph);
	}
}