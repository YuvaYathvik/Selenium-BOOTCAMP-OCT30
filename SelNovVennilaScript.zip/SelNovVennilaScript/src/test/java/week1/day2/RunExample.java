package week1.day2;

import java.util.Iterator;

@SuppressWarnings("unused")
public class RunExample {

	public static void main(String[] args) {
		

		for (int i = 1; i <=10; i++) {
			System.out.println("Run round: "+i);
			
		}
	}
	

		
		
}

}	