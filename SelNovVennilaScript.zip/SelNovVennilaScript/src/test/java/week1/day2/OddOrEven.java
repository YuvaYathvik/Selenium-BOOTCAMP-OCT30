package week1.day2;

import java.util.Iterator;

public class OddOrEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 50;
		
		if (num%2 == 0) {
			System.out.println("This is odd number"); 
			} else {
				System.out.println("This is even number");
			}
			
		}
	}


