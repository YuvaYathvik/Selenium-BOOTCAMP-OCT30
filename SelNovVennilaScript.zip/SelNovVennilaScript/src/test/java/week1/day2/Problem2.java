package week1.day2;

import java.util.Iterator;

public class Problem2 {

	public static void main(String[] args) {
		
		String reverse = "tester working with application";
		
		
		//char[] character = reverse.toCharArray();
		
					
		//for (int i = character.length - 1; i >= 0; i--) {
			//System.out.print(character[i]);
			
		//	for (int i = reverse.length() - 1; i >= 0; i--) {
			//	System.out.println(reverse.charAt(i));
				
				String[] split = reverse.split(" ");
				System.out.println(split.length);
				
			}
			
		}
			
			
			
		
			
		

	


