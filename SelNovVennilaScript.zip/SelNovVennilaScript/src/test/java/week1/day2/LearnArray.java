package week1.day2;

import java.util.Arrays;

import org.testng.annotations.Test;


public class LearnArray {
@Test (dependsOnMethods = {week1.day2.FindMissingNumber.FindMissingNumber})
	public void testcase2() {
		// TODO Auto-generated method stub
 
		int [] input = {77, 75, 78, 77, 98, 75};
		Arrays.sort(input);
		for (int i = 0; i < input.length - 1; i++) {
		if (input [i] == input [i+1]) {
			System.out.println(input[i]);
				
			}
			
		}
		
	}

}
