package week1.day2;

public class TwoSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] input = {2,3,4,5};
		int S = 20;
		boolean bmatch = false;
		
		for (int i = 0; i < input.length; i++) {
			for (int j = i+1; j < input.length; j++) {
				if (input [i] + input [j] == S) {
					bmatch = true;
					System.out.println("True");
					break;
					
					
				}
				
			}
		if (bmatch) 
			break;
			
		}
			
		
		
		if (!bmatch)
		System.out.println("False");
			

	}

}
