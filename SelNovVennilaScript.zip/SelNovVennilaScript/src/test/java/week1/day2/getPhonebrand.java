package week1.day2;

public class getPhonebrand {

	public String getPhonebrand (String Phontype) {
		if(PhoneType.equals ("Android")) 
			retrun "One plus 5";
		else
			retrun "I phone"
		
		return Phontype;
	
		// TODO Auto-generated method stub

	}

}
