package week1.day1;



public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String reverse = "Yuvaraj";
		
	String [] words = reverse.split("");
		for (int i = reverse.length() - 1; i>=0; i--) {
			//System.out.println(reverse.charAt(i));
			System.out.println(words[i]+"");
			
		}
	}

}
