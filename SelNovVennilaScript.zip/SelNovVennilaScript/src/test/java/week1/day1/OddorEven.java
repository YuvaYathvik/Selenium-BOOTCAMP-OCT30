package week1.day1;

public class OddorEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	//	int num = 10;
		//for loop -> same code for multiple time run
		 for (int i = 0; i<=100; i++) {
			 if (i ==0) {
				 System.out.println("neutral number: "+i);
			 }else if(i%2 ==0) {
				 System.out.println("Even number:"+ i);
				
			}else { System.out.println("Odd number:"+i);
			
		}
	}
	}
}
