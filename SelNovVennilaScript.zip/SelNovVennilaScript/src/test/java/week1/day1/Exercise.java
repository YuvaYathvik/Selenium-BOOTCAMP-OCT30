package week1.day1;

import java.awt.List;

public class Exercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 1; i<=100; i++) {
			if (i%3==0) {
				System.out.println("the number is "+i+" and the value is PAN TAN");
			}else
				if (i%5==0) {
					System.out.println("the number is "+i+" and the value is PAN");
				}else
					if (i%3==0 && i%5==0){
						System.out.println("the number is "+i+" and the value is PAN PAN");
					}else 
						System.out.println("else do nothing");
						
					}
					
				}
				
			
			
		
	}

         public String getcyclecolour (String cyclecolour) {
	     return "Red Colour";
	     
	     public boolean ispuncher(boolean ispuncher) {
	    	 if(ispuncher) {
	    		 System.out.println("This cycle is puncher");
	    	 } else {
	    		 System.out.println("This cycle is not puncher");
	    		 
	    	public static void main1 (String[] args) {
	    		
	    		Exercise biycle = new Exercise();
	    		
	    		Object bicycle;
				((Exercise) bicycle).ispuncher(true);
	    		String Red colour = ((Object) bicycle).getcyclecolour();
	    		char[] cyclecolour;
				System.out.println(cyclecolour);
				
				List<Webelement> options = dd.getOptions ();
				for (Webelement: eachElement:Option) {
					
				}
	    		
	    		
	    		
	    		
	    	}
	    			 
	    	 
	     }
}

