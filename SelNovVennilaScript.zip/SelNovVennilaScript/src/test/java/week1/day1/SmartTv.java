package week1.day1;

public class SmartTv {
	
	public static void main(String[] args) {
		
		int carPrice = 27000;
		
		System.out.println("This is my first java code ! ! ");
	}

}
