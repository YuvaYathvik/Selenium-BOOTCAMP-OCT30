package Selenium.Started.Nov;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.ClickAction;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@SuppressWarnings("deprecation")

public class Customer_Service_Options {

	public static void main(String[] args) throws InterruptedException {
	
		WebDriverManager.chromedriver().setup();
	    
		  ChromeDriver driver  = new ChromeDriver();
					    
		  //Handle Notification
		  ChromeOptions options=new ChromeOptions();
		  options.addArguments("--disable-notifications");
				
		  //Application url
		  driver.get("https://login.salesforce.com");
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			    
		  System.out.println(driver.getWindowHandle());
		  //Login Page	    
		  driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");
		  driver.findElement(By.id("password")).sendKeys("SelBootcamp$1234");
		  driver.findElement(By.id("Login")).click();
		  Thread.sleep(10000);
				
		 //3. Click on Learn More link in Mobile Publisher
		  driver.executeScript("arguments [0].click()",driver.findElement(By.xpath("//button[@title = 'Learn More']")));
		 
		  Thread.sleep(1000);
		  
		  Set <String> allWindowHandles  = driver.getWindowHandles();
		  List <String> lstWindows = new ArrayList<String>(allWindowHandles);
		  
		  String secondWindowHandle = lstWindows.get(1);
		
		  //Move the control to the second window
		  driver.switchTo().window(secondWindowHandle);
		 
		  //Confirm the title and current url
		  System.out.println("Moved?"+driver.getTitle());
		  	System.out.println("Moved?"+driver.getCurrentUrl());
		  	
		  	Thread.sleep(5000);
		  	
		 // 4. MouseHover on Products and Select Service
		  JavascriptExecutor YS = (JavascriptExecutor) driver;
		  WebElement eleProducts = (WebElement) YS.executeScript("return document.querySelector(\"#c360-hgf-nav\").shadowRoot.querySelector(\"header > div:nth-child(2) > div > div > div > div > div.globalnavbar-header-container > nav > ul > li.nav-item.menu_item_0 > button\")");
		  
		  
		  //Move to element
		  Actions bulider = new Actions(driver);
		  bulider.moveToElement(eleProducts).perform();

		  WebElement ClickSales = (WebElement) YS.executeScript("return document.querySelector(\"#c360-hgf-nav\").shadowRoot.querySelector(\"header > div:nth-child(2) > div > div > div > div > div.globalnavbar-header-container > nav > ul > li.nav-item.menu_item_0 > div > div > div > div:nth-child(1) > ul > li > div.sub-nav > ul > li:nth-child(3) > a > span\")");
		  JavascriptExecutor executor2 = (JavascriptExecutor) driver;
		  driver.executeScript("arguments[0].click()", ClickSales);
		  
		 // 5. Verify the tabs displayed in the page
		  
		
		  
		  
		 // Expected Result:
		//  Below tabs should be displayed

		  	
		

	}

}
