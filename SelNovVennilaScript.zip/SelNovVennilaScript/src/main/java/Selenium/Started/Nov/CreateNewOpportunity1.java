package Selenium.Started.Nov;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

public class CreateNewOpportunity1 extends BaseClass{
   @Ignore
	@Test (dataProvider = "TestData")
	public void createnewOpp (String Name, String CloseDate) {
		
		
		   driver.findElement(By.xpath("//input[@name = 'Name']")).sendKeys("Salesforce Automation by Yuvaraj S");
		   driver.findElement(By.xpath("//input[@name = 'CloseDate']")).sendKeys("11/13/2021");
	}



}
