package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecifiedMethod;

public class NewWorkTypeGroup extends ProjectSpecifiedMethod{

	 public NewWorkTypeGroup EnterSalesforceAutomationbyDev () {
	  driver.findElement(By.xpath("(//span[@title = 'required']/following::input)[1]")).sendKeys("Salesforce Automation by Yuvaraj S");
	  
	  return this;
	 }
	  

	 public NewWorkTypeGroup clickSave () {
	 driver.findElement(By.xpath("//button[@title = 'Save']")).click();
	 
	 return this;
	 }
	 
	 public NewWorkTypeGroup clickVerify () {
	 String text = driver.findElement(By.xpath("(//span [@class = 'uiOutputText'])[2]")).getText();
	 System.out.println(text);
	
	 return this;
		
	}
	
}
