package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;

public class EditSubscription extends ProjectSpecifiedMethod{

	//Select Frequency as "Daily"
	public EditSubscription clickDaily () {
	driver.switchTo().defaultContent();
	driver.findElement(By.xpath("//span[text() = 'Daily']")).click();
	
	return this;
}

	//Time as 10:00 AM
	public EditSubscription selectTime () throws InterruptedException {
	driver.findElement(By.xpath("//select[@id = 'time']")).click();
	driver.findElement(By.xpath("//option[text()= '10:00 AM']")).click();
	Thread.sleep(1000);
	return this;
}	
	//Click on Save
	public EditSubscription clickSave () {
	driver.findElement(By.xpath("//button[@title = 'Save']")).click();
	
	return this;
	}

	//Verify "You started Dashboard Subscription" message displayed or not
	public EditSubscription VerifyMessage () throws InterruptedException {
	String text = driver.findElement(By.xpath("//span[text() = 'You started a dashboard subscription.']")).getText();
	System.out.println(text);
	Thread.sleep(1000);
	return this;
	
	}
	
	//Close the "YourName_Workout" tab
	public EditSubscription clickCloseYuvaraj () throws InterruptedException {
	driver.findElement(By.xpath("//button[@title = 'Close Yuvaraj_Workout']")).click();
	Thread.sleep(1000);
	return this;
	}
	
	//Click on Private Dashboards
	public EditSubscription clickPrivate () throws InterruptedException {
	WebElement Private = driver.findElement(By.xpath("//a[@title = 'Created by Me']/following::li/a[@title = 'Private Dashboards']"));
    JavascriptExecutor exe2 = (JavascriptExecutor) driver;
    driver.executeScript("arguments[0].click()",Private);
    Thread.sleep(1000);
    return this;
	}

	//Verify the newly created Dashboard available
	public EditSubscription SearchYourName () throws InterruptedException {
	driver.findElement(By.xpath("//input [@placeholder = 'Search private dashboards...']")).sendKeys("Yuvaraj_Workout"+ Keys.ENTER);
    Thread.sleep(1000);
	return this;
	}
	
	//Click on dropdown for the item
	public EditSubscription clickEditDropDown () throws InterruptedException {
	WebElement dropdown = driver.findElement(By.xpath("//span[text() = 'Show actions']/following::button[@class = 'slds-button slds-button_icon-border slds-button_icon-x-small']"));
	JavascriptExecutor exe3 = (JavascriptExecutor) driver;
	driver.executeScript("arguments[0].click()",dropdown);
	Thread.sleep(1000);
	return this;
	
	}
	
	//Select Delete
	public EditSubscription clickDelete () throws InterruptedException {
	WebElement delete = driver.findElement(By.xpath("//span[text() = 'Delete']"));
	JavascriptExecutor exe5 = (JavascriptExecutor) driver;
	driver.executeScript("arguments[0].click()", delete);
	Thread.sleep(1000);
	return this;
	
	}
	
	//Confirm the Delete
	public EditSubscription clickConfirmDelete () throws InterruptedException {
	driver.findElement(By.xpath("//button[@title = 'Delete']")).click();
	Thread.sleep(1000);
	
	return this;
	}
	
	//Verify the item is not available under Private Dashboard folder
	public EditSubscription VerifyDelete () {
	String text = driver.findElement(By.xpath("//span[@class = 'toastMessage slds-text-heading--small forceActionsText']")).getText();
	System.out.println(text);
	
	return this;
	}
}