package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecifiedMethod;

public class LoginPage extends ProjectSpecifiedMethod{

	public LoginPage EnterUserName (String UserName) throws InterruptedException {
	driver.findElement(By.id("username")).sendKeys(UserName);
	return this;
	}
    public LoginPage EnterPassword (String Password) {
    driver.findElement(By.id("password")).sendKeys(Password);
    	
    	return this;
}
    
    public HomePage clickLoginButton() {
    driver.findElement(By.id("Login")).click();	
    
    
    return new HomePage();
    
   
    
    
    
    }
    }