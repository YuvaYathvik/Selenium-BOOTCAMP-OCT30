package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;

public class HomePage extends ProjectSpecifiedMethod{

		public HomePage clicktongglebutton() {
			 driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		
			 return this;
			
		}
		
		public HomePage clickviewall() {
			driver.findElement(By.xpath("//button[text()='View All']")).click();
			
			return this;
		}
		public IndividualPage clickIndividual() {
		WebElement click = driver.findElement(By.xpath("//p [ text () = 'Individuals']"));
		JavascriptExecutor exe = (JavascriptExecutor) driver;
		driver.executeScript("arguments [0].click();", click);
		
		return new IndividualPage();

		}
		public LegalPage clickLeganEntities() {
	    WebElement click1 = driver.findElement(By.xpath("//p[text() = 'Legal Entities']"));
	    JavascriptExecutor executor = (JavascriptExecutor) driver;
	    driver.executeScript("arguments[0].click();", click1);
	    
	    return new LegalPage();
	    
		}
		
        public HomePage clickSales () {
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
        return new HomePage();
}

        public OpportunityPage clickOpportunities() {
        WebElement click2 = driver.findElement(By.xpath("(//span[text()='Opportunities'])[1]"));
 	    JavascriptExecutor executor = (JavascriptExecutor) driver;
        driver.executeScript("arguments[0].click();", click2);
        
        return new OpportunityPage();
        }

        public NewTaskPage clickNewTaskdropdown () {
	    WebElement click3 = driver.findElement(By.xpath("//a[@title = 'Tasks']/following::div/one-app-nav-bar-menu-button/a/lightning-icon[1]"));
	    JavascriptExecutor executor = (JavascriptExecutor) driver;
		driver.executeScript("arguments[0].click();", click3);
		
		return new NewTaskPage();
}

         public HomePage clickWorkTypeGroup () throws InterruptedException {
		 WebElement click7 = driver.findElement(By.xpath("//p[text() = 'Work Type Groups']"));
		 JavascriptExecutor executor = (JavascriptExecutor) driver;
		 driver.executeScript("arguments[0].click();", click7);
		 Thread.sleep(10000);
		 return this;
		 
         }
         
		 public HomePage clickDropdownIconintheWorkTypeGroupstab () throws InterruptedException {
		 driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Work Type Groups Menu']")));
		 Thread.sleep(5000);
		 
		 return this;
		 
		 }	  
		 public NewWorkTypeGroup clickNewWorkTypeGroup() throws InterruptedException {
		 driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='New Work Type Group']")));
		 Thread.sleep(3000);
		 
		 return new NewWorkTypeGroup ();
		 }
		 
		 public HomePage clickSalesConsole()  {
		 driver.findElement(By.xpath("//p[text() = 'Sales Console']")).click();
		 return this;
}

		 public HomePage clickHomeDropDown() throws InterruptedException  {
		 WebElement click4 = driver.findElement(By.xpath("//button[@title = 'Show Navigation Menu']"));
		 JavascriptExecutor executor4 = (JavascriptExecutor) driver;
		 driver.executeScript("arguments [0].click();", click4);
		 Thread.sleep(1000);
		 return this;
		 }
		 
      	//Select Home from the DropDown
		 public DashboardsPage clickDashboard () {
		 WebElement click5 = driver.findElement(By.xpath("//span[text() = 'Dashboards']"));
		 JavascriptExecutor exe5 = (JavascriptExecutor) driver;
		 driver.executeScript("arguments[0].click();", click5);
		 
		 return new DashboardsPage();
		 }
}