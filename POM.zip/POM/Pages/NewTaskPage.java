package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.ProjectSpecifiedMethod;

public class NewTaskPage extends ProjectSpecifiedMethod{

	
	   public NewTaskPage ClickNewTask () throws InterruptedException {
	   driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='New Task']")));
	   Thread.sleep(1000);

	   return this;
	   }
	   public NewTaskPage EnterBootcamp () {
	   driver.findElement(By.xpath("(//input[@aria-haspopup= 'listbox'])[2]")).sendKeys("Bootcamp");
		
	   return this;
	   }
	   public NewTaskPage SelectWaitingonsomeoneelse () {
	   driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("(//a[@class = 'select'])[1]")));
		driver.executeScript("arguments [0].click()",driver.findElement(By.xpath("//a[@title = 'Waiting on someone else']")));
	
		return this;
	   }
	   public NewTaskPage SelectDropDown () throws InterruptedException {
	   driver.findElement(By.xpath("(//span[text() = 'Pick an object']//following::div/input)[3]")).click();
	   Thread.sleep(1000);
	   driver.findElement(By.xpath("//div[@class = 'listContent']/ul/li/a/div/div")).click();
	   
	   return this;
	   }

	   public NewTaskPage VerifyTaskCreatedMessage () {
	   driver.findElement(By.xpath("//button[@title = 'Save']")).click();
	    String text = driver.findElement(By.xpath("//span[@class= 'toastMessage slds-text-heading--small forceActionsText']")).getText();
        System.out.println(text);
	
        return this;
   }
}