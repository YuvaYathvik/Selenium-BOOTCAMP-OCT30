package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;

public class OpportunityPage extends ProjectSpecifiedMethod{

	public OpportunityPage clickNew() {
        driver.findElement(By.xpath("//div[text() = 'New']")).click();
        
        return this;
        }
	
        public OpportunityPage enterSalesforce(String data) {
 	    driver.findElement(By.xpath("//input[@name = 'Name']")).sendKeys(data);
 	    
 	    return this;
 	    
        }
        
        public OpportunityPage enterDate(String data) {
 	    driver.findElement(By.xpath("//input[@name = 'CloseDate']")).sendKeys(data);
 	   
 	    return this;
 	    
        }
       
       public OpportunityPage clickdropdown() {
       WebElement none = driver.findElement(By.xpath("(//div[@role='none']//input)[3]"));
 	   JavascriptExecutor executor1 = (JavascriptExecutor) driver;
       driver.executeScript("arguments[0].click();", none);
        
       return this;
       }
       
       public OpportunityPage clickAnalysis() {
 	   driver.findElement(By.xpath("//div[@role = 'listbox']/lightning-base-combobox-item[4]/span[2]")).click();
 	   
 	   return this;
       }
       
       public OpportunityPage clickSave() {
 	   driver.findElement(By.xpath("//li[@class ='slds-button-group-item visible']//button[text() = 'Save']")).click();
 	   System.out.println("Salesforce Automation by Yuvaraj S");
 	   
 	   return this;
       }  
 	   
}

