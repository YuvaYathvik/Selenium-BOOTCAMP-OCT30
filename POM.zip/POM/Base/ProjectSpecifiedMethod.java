package Base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import Selenium.Started.Nov.ReadExcel;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecifiedMethod {

	public static ChromeDriver driver;
	
	public String excelFileName;
	
	    @SuppressWarnings("deprecation")
	    @BeforeMethod
	    public void launchApplication() {
		WebDriverManager.chromedriver().setup();
	    
		 //Handle Notification
		  ChromeOptions options=new ChromeOptions();
		  options.addArguments("--disable-notifications");
		  
		   driver  = new ChromeDriver();
					    
		 
				
		  //Application url
		  driver.get("https://login.salesforce.com");
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    }
	
	//   @AfterMethod
	//   public void closebrowser() {
	//   driver.close();
	

    @DataProvider (name = "fetchData")
	public Object [][] fetchData ()throws IOException, Exception{
    return ReadExcel.readExcelData(excelFileName);
   
    }
}