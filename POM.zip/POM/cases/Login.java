package cases;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.IndividualPage;
import Pages.LoginPage;

public class Login extends ProjectSpecifiedMethod{

	@BeforeTest
	public void setfile () {
		excelFileName = "Credentials";
	}
	@Test (dataProvider = "fetchData")
	public void runLogin(String UserName, String Password) throws InterruptedException {
		LoginPage run = new LoginPage();
		
		 run.EnterUserName(UserName)
		.EnterPassword(Password)
		.clickLoginButton();
		
		
		
		
		
	}
}
