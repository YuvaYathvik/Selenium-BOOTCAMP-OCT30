package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class Legal extends ProjectSpecifiedMethod{

	@Test
	public void runLegal () throws InterruptedException {

		new LoginPage()
		.EnterUserName("makaia@testleaf.com")
		.EnterPassword("SelBootcamp$1234")
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickLeganEntities()
		.clickdropdown()
		.clickNewlegalEntity()
		.EnterYourName()
		.clickSave()
		.verify();
		
}
}