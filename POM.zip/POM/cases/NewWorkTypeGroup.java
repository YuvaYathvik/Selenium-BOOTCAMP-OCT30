package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class NewWorkTypeGroup extends ProjectSpecifiedMethod {

	@Test
	public void runNewWorkTypeGroup () throws InterruptedException {
		
		new LoginPage()
		.EnterUserName("makaia@testleaf.com")
		.EnterPassword("SelBootcamp$1234")
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickWorkTypeGroup()
		.clickDropdownIconintheWorkTypeGroupstab()
		.clickNewWorkTypeGroup()
		.EnterSalesforceAutomationbyDev()
		.clickSave()
		.clickVerify();
			
		
	}
}
