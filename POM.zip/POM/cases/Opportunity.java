package cases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class Opportunity extends ProjectSpecifiedMethod{

	@BeforeTest
	public void setfile () {
		excelFileName = "Opportunity";
	}
	@Test(dataProvider = "fetchData")
	public void runOpportunity (String UserName, String Password, String Salesforce, String Date) throws InterruptedException {
		
		new LoginPage()
		.EnterUserName(UserName)
		.EnterPassword(Password)
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickSales()
		.clickOpportunities()
		.clickNew()
		.enterSalesforce(Salesforce)
		.enterDate(Date)
		.clickdropdown()
		.clickAnalysis()
		.clickSave();
	}
}
