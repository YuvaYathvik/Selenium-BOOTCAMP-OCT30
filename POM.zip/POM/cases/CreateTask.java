package cases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class CreateTask extends ProjectSpecifiedMethod{

    @Test
	public void runCreateTask () throws InterruptedException {
		
		new LoginPage()
		.EnterUserName("makaia@testleaf.com")
		.EnterPassword("SelBootcamp$1234")
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickSales()
		.clickNewTaskdropdown()
		.ClickNewTask()
		.EnterBootcamp()
		.SelectWaitingonsomeoneelse()
		.SelectDropDown()
		.VerifyTaskCreatedMessage();
		
		
		
	}
	
	
}
