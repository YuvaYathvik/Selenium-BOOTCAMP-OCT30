package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class Individual extends ProjectSpecifiedMethod{

	@Test
	public void runIndividual () throws InterruptedException {
		
		 new LoginPage()
		.EnterUserName("makaia@testleaf.com")
		.EnterPassword("SelBootcamp$1234")
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickIndividual()
		.clickIndividualMenu()
		.clickNewIndividual()
		.enterYathvik()
		.clicksave();
	
	}
	
}
