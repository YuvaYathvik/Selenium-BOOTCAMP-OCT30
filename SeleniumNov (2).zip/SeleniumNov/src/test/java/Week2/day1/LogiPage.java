package Week2.day1;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.mongodb.MapReduceCommand.OutputType;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LogiPage {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
    WebDriverManager.chromedriver().setup();
    
    ChromeDriver driver  = new ChromeDriver();
    
    driver.get("http://leaftaps.com/opentaps");
    driver.manage().window().maximize();
    
    driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
    driver.findElement(By.id("password")).sendKeys("crmsfa");
    driver.findElement(By.className("decorativeSubmit")).click();
    String text = driver.findElement(By.tagName("h2")).getText();
    System.out.println(text);
    
   driver.findElement(By.linkText("CRM/SFA")).click();
   driver.findElement(By.linkText("Leads")).click();
   driver.findElement(By.linkText("Find Leads")).click();
   driver.findElement(By.xpath("//span[text()= 'Phone']")).click();
   driver.findElement(By.name("phoneCountryCode")).clear();
   //driver.findElement(By.name("phoneNumber")).sendKeys("9999999999");
   driver.findElement(By.xpath("//button[text() = 'Find Leads']")).click();
   Thread.sleep(2000);
   
   driver.findElement(By.xpath("//div[@class = 'x-grid3-cell-inner x-grid3-col-partyId']//a")).click();
   
   //How to take snapshot
   File src = driver.getScreenshotAs(org.openqa.selenium.OutputType.FILE);
   File dev = new File("./snap1.png");
   FileUtils.copyFile(src, dev);
   
   
 	}

}
