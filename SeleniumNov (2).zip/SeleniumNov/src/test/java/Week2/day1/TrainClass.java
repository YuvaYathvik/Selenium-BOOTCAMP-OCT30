package Week2.day1;

public class TrainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
