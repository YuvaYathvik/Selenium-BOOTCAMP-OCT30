package Practise;

import java.util.Iterator;

import net.bytebuddy.dynamic.scaffold.MethodRegistry.Handler.ForAbstractMethod;

public class ReverseName {

	public static void main(String[] args) {
		
	String reverse = "Devyathvik";
	
	String [] words = reverse.split("");
	for (int i = reverse.length() -1; i >= 0; i--) {
	System.out.println(words[i]+"");
	
	}
	}
   
	}


