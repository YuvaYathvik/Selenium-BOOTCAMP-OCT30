package Practise;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Iterator;

public class FindDuplicateNumber {

	public static void main(String[] args) {
		
		int [] data = {23,25,58,22,23,58,70,60,70};
		
		Arrays.sort(data);
	    for (int i = 0; i < data.length-1; i++) {
	    	if (data [i] == data [i+1]) {
	    		System.out.println(data[i]);
				
			}
			
		}
		
		
		

	}

}
