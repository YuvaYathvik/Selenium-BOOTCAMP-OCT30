package Practise;

public class Replace {

	public static void main(String[] args) {
		
		//Replace
		String Company = "New Work";
		
		String replaceText = Company.replace("New", "Old");
		System.out.println(replaceText);

	}

}
