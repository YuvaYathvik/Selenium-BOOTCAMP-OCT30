package Practise;

import javax.print.DocFlavor.CHAR_ARRAY;

public class ReverseMethodTwo {

	public static void main(String[] args) {
		//method 1
        String data = "cognizant is good company";
		
        /*  for (int i = data.length()-1; i >= 0; i--) {
	    	System.out.print(data.charAt(i)); 

	}*/
		//Method 2
		char [] charArray =  data.toCharArray();
		for (int i = data.length()-1; i >= 0; i--)
			System.out.print(charArray[i]);
	}
	
}
