package week3.day1;

public class SamsungTV implements AndroidTV{

	public void colour() {
		// TODO Auto-generated method stub
		
	}

	public boolean Changevolume() {
		// TODO Auto-generated method stub
		return false;
	}

	public String getChannelName() {
		// TODO Auto-generated method stub
		return null;
	}

   public void chooselanguage(String lang){
	   
   }
}
