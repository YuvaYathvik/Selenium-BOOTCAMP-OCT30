package week3.day1;

public class Overriding extends Base{

	public static void main(String[] args) {


	}

	sum uv = new sum();
	
	public void sum() {
		System.out.println("dup");
}
