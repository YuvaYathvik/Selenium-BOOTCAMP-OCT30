package week3.day1;

public interface AndroidTV {

	
	public void colour ();
	
	boolean Changevolume ();
	
	String getChannelName ();
	
	
	
}
