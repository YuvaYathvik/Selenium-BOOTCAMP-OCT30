package week3.day1;

public class Overloading {

	public static void main(String[] args) {
   

	}
    public void sum() {
    	System.out.println("Yuvaraj");
    }
    
    public void sum(int i) {
    	System.out.println("Dev");
    }
    
    public void sum(int k, int l) {
    	System.out.println("Sandhiya");
    }
    
}

