package week1.day1;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.github.bonigarcia.wdm.config.WebDriverManagerException;
import io.netty.channel.pool.FixedChannelPool.AcquireTimeoutAction;

public class AssertionClass {
	@Test
	@SuppressWarnings("deprecation")
	public void Titlematch () {
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://learn.academiatorah.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@title = 'Get Started']']")).click();
		String ExpectedResult = "https://learn.academiatorah.com/register";
		String ActualResult = driver.getTitle();
		assertEquals("ExpectedResult", "ActualResult", "Title is matched");
		driver.quit();
		
		
		

}

	
}