package week1.day1;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String [][] readData () throws IOException {
		
		//get in to workbook path
		XSSFWorkbook wb = new XSSFWorkbook("./data/Create Individulas.xlsx");
		
		//get in to the sheet
		XSSFSheet ws = wb.getSheet("Create Individuals");
		
		//Number of Rows
		int rowCount =  ws.getLastRowNum();
		short cellcount = ws.getRow(0).getLastCellNum();
		
		
		//include first number of rows	
	 //   int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		
		//System.out.println(rowCount);
		//System.out.println(physicalNumberOfRows);
		
		for (int i = 1; i <=rowCount; i++) {
		for (int j = 0; j < cellcount; j++) {
			

		//Another way to set the excel data
		String cellvalue = ws.getRow(i).getCell(j).getStringCellValue();
		
		data [i-1][j] = cellvalue;
		System.out.println(cellvalue);
		
		//get in to the row
		//XSSFRow row = ws.getRow(i);
		
		//get in to the cell
	//	XSSFCell cell = row.getCell(0);
		
		//to read string data from a cell
	//	String cellvalue = cell.getStringCellValue();
		
	
		
		wb.close();
		
		return data;
		}

	}
	}
	}
