package week1.day1;

public class RunExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    for (int i = 1; i <=10; i++) {
    	System.out.println("Running round: "+ i);
	
}
	System.out.println("After for loop");
	}
	

}
