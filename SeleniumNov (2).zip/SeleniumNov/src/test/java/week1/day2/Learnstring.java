package week1.day2;

public class Learnstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = new String ("India");
		
	int length = str.length();
	System.out.println(length);
	
	char[] charArray = str.toCharArray();
	System.out.println(charArray);
	
	String lowerCase = str.toLowerCase();
	System.out.println(lowerCase);
	
	String upperCase = str.toUpperCase();
	System.out.println(upperCase);
	
System.out.println(str.contains("dia"));
System.out.println(str.endsWith("In"));
System.out.println(str.startsWith("a"));
System.out.println(str.indexOf('N'));

//String input = "Yuvaraj";
char search =  'a';
int count = 0;

//char[] character = input.toCharArray();

//for (int i = 0; i < character.length; i++) {
 //if (character[i] == search) {
	 count ++;
	 System.out.println(count);
	 
	 boolean equals = str.equals("India");
	 System.out.println(equals);
	 
	 String input = "test leaf";
	char[] character = input.toCharArray();
	boolean bfoundduplicate = false;
	
	 for (int j = 0; j < character.length; j++) {
		 for (int j2 = j+1; j2 < character.length; j2++) {
			 if (character [j] == character [j2]) {
				 System.out.println("This is duplicate : "+character[j]);
			 bfoundduplicate = true;
			 break;
				 
				
			}
			
		}
		 
			 if(bfoundduplicate)
				 break;
		 }
		 
		
	

	if(!bfoundduplicate)
		System.out.println("no dups");
			

		}
}
		
	
	

	
	


	