package week1.day2;

import java.util.Iterator;

public class Reverse2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//String data =  "Work hard for future";
		
//		String[] word = data.split(" ");
	//for (int i = word.length - 1; i >=0; i--) {
		//System.out.print(word[i]+" ");
		
	//	String replacedtext = data.replace("hard", "Great");
		//System.out.println(replacedtext);
		
		String remove = "testleaf";
	    /*char[] chars = remove.toCharArray();
	    for (int i = 0; i < chars.length; i++) {
	    	if (chars [i] == 'a' || chars [i] == 'e' || chars [i] == 'o' || chars [i] == 'u') {
				
			} else {

				/*System.out.print(chars[i] );
				 * 
				 * 
				 */
	//String replaceAll = remove.replaceAll("[aeiou]","");
	//System.out.println(replaceAll);
	
	String desc = " Find the place for you 17777,77 in future";
	
	String replaceAll = desc.replaceAll("[^0-9]", "");
	System.out.println(replaceAll);
	x`
	}
	
			
		
		
		
		
				
		
	}
	


