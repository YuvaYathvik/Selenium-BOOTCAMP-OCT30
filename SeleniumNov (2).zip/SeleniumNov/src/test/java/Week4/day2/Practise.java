package Week4.day2;

public class Practise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
