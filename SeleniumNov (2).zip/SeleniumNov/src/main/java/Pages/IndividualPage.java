package Pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Base.ProjectSpecifiedMethod;

public class IndividualPage extends ProjectSpecifiedMethod{
	

	public IndividualPage clickIndividualMenu() {
	WebElement click1 = driver.findElement(By.xpath(prop.getProperty("IndividualPage.clickIndividualMenu.xpath")));
	JavascriptExecutor exe1 = (JavascriptExecutor) driver;
	driver.executeScript("arguments [0].click()", click1);
	  
	 return this;
	}
	 public IndividualPage clickNewIndividual() {
	  WebElement click2 = driver.findElement(By.xpath(prop.getProperty("IndividualPage.clickNewIndividual.xpath")));
	  JavascriptExecutor exe2 = (JavascriptExecutor) driver;
	  driver.executeScript("arguments [0].click()", click2);
	  
	  return this;
	 }
	  
	 public IndividualPage enterYathvik() {
	 driver.findElement(By.xpath(prop.getProperty("IndividualPage.enterYathvik.xpath"))).sendKeys(prop.getProperty("LastName"));
	  
	 return this;
	 }
	  
	 public IndividualPage clicksave() {
	 driver.findElement(By.xpath(prop.getProperty("IndividualPage.clicksave.xpath"))).click();
	 
	 return this;
	 }
	 
	 
}
