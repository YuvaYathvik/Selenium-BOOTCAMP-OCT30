package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;

public class OpportunityPage extends ProjectSpecifiedMethod{

	public OpportunityPage clickNew() {
        driver.findElement(By.xpath(prop.getProperty("OpportunityPage.clickNew.xpath"))).click();
        
        return this;
        }
	
        public OpportunityPage enterSalesforce() {
 	    driver.findElement(By.xpath(prop.getProperty("OpportunityPage.enterSalesforce.xpath"))).sendKeys(prop.getProperty("enterSalesforce "));
 	    
 	    return this;
 	    
        }
        
        public OpportunityPage enterDate() {
 	    driver.findElement(By.xpath(prop.getProperty("OpportunityPage.enterDate.xpath"))).sendKeys(prop.getProperty("enterDate"));
 	   
 	    return this;
 	    
        }
       
       public OpportunityPage clickdropdown() {
       WebElement none = driver.findElement(By.xpath(prop.getProperty("OpportunityPage.clickdropdown.xpath")));
 	   JavascriptExecutor executor1 = (JavascriptExecutor) driver;
       driver.executeScript("arguments[0].click();", none);
        
       return this;
       }
       
       public OpportunityPage clickAnalysis() {
 	   driver.findElement(By.xpath(prop.getProperty("OpportunityPage.clickAnalysis.xpath"))).click();
 	   
 	   return this;
       }
       
       public OpportunityPage clickSave() {
 	   driver.findElement(By.xpath(prop.getProperty("OpportunityPage.clickSave.xpath"))).click();
 	   System.out.println("Salesforce Automation by Yuvaraj S");
 	   
 	   return this;
       }  
 	   
}

