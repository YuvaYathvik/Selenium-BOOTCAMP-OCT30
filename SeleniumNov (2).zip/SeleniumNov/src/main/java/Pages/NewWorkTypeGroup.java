package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecifiedMethod;

public class NewWorkTypeGroup extends ProjectSpecifiedMethod{

	 public NewWorkTypeGroup EnterSalesforceAutomationbyDev () {
	  driver.findElement(By.xpath(prop.getProperty("NewWorkTypeGroup.EnterSalesforceAutomationbyDev.xpath"))).sendKeys(prop.getProperty("EnterSalesforceAutomationbyDev"));
	  
	  return this;
	 }
	  

	 public NewWorkTypeGroup clickSave () {
	 driver.findElement(By.xpath(prop.getProperty("NewWorkTypeGroup.clickSave.xpath"))).click();
	 
	 return this;
	 }
	 
	 public NewWorkTypeGroup clickVerify () {
	 String text = driver.findElement(By.xpath(prop.getProperty("NewWorkTypeGroup.clickVerify.xpath"))).getText();
	 System.out.println(text);
	
	 return this;
		
	}
	
}
