package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;
import cases.Dashboards;

public class DashboardsPage extends ProjectSpecifiedMethod{

	//Click on New Dashboard
	public NewDashboardPage clickNewDashboard() throws InterruptedException {
	WebElement click = driver.findElement(By.xpath(prop.getProperty("NewDashboardPage.clickNewDashboard.xpath")));
	JavascriptExecutor exe = (JavascriptExecutor) driver;
	driver.executeScript("arguments[0].click();", click);
	Thread.sleep(1000);
	
	return new NewDashboardPage ();
}
			}
			
	
