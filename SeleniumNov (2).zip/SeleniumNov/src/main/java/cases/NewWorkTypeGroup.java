package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class NewWorkTypeGroup extends ProjectSpecifiedMethod {

	@Test
	public void runNewWorkTypeGroup () throws InterruptedException {
		
		new LoginPage()
		.EnterUserName()
		.EnterPassword()
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.clickWorkTypeGroup()
		.clickDropdownIconintheWorkTypeGroupstab()
		.clickNewWorkTypeGroup()
		.EnterSalesforceAutomationbyDev()
		.clickSave()
		.clickVerify();
			
		
	}
}
