package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecifiedMethod;
import cases.Dashboards;

public class DashboardsPage extends ProjectSpecifiedMethod{

	//Click on New Dashboard
	public NewDashboardPage clickNewDashboard() throws InterruptedException {
	Thread.sleep(1000);
	WebElement click = driver.findElement(By.xpath(prop.getProperty("NewDashboardPage.clickNewDashboard.xpath")));
	JavascriptExecutor exe = (JavascriptExecutor) driver;
	driver.executeScript("arguments[0].click();", click);
	Thread.sleep(1000);
	
	return new NewDashboardPage ();
}
	
	 //click on searchbar
     public DashboardsPage SearchRecentDashboards() throws InterruptedException {
     driver.findElement(By.xpath(prop.getProperty("DashboardPage.SearchRecentDashboards.xpath"))).sendKeys("Yuvaraj S"+ Keys.ENTER);
	 Thread.sleep(1000);
     return this;
}

     //Click on the Dropdown icon and Select Subscribe
     public DashboardsPage clickDropDown() throws InterruptedException {
     WebElement click1 = driver.findElement(By.xpath(prop.getProperty("DashboardsPage.clickDropDown.xpath")));
	 JavascriptExecutor executor1 = (JavascriptExecutor) driver;
	 driver.executeScript("arguments [0].click();", click1);
	 Thread.sleep(1000);
	 
	 return this;
     
}

     //Select Subscribe
     public DashboardsPage SelectSubscribe () {
     WebElement click2 = driver.findElement(By.xpath(prop.getProperty("DashboardsPage.SelectSubscribe.xpath")));
	 JavascriptExecutor exe = (JavascriptExecutor) driver;
	 driver.executeScript("arguments [0].click();", click2);
	 
	 return this;
     }
     
    //Select frequency as 'Daily'
     public DashboardsPage SeleckDaily() throws InterruptedException {
     driver.findElement(By.xpath(prop.getProperty("DashboardsPage.SeleckDaily.xpath"))).click();
     Thread.sleep(1000);
     return this;
     }
	
     //Click on Save in the Edit Subscription popup window.
     public DashboardsPage ClickSave () {
     driver.findElement(By.xpath(prop.getProperty("DashboardsPage.ClickSave.xpath"))).click();
     
     return this;
     }   
     
     //Verify Whether the dashboard is subscribed.
     public DashboardsPage VerifySubscribe () {
     String text = driver.findElement(By.xpath(prop.getProperty("DashboardsPage.VerifySubscribe.xpath"))).getText();
	 	
	 System.out.println(text);
     
     return this;
     
     }
}