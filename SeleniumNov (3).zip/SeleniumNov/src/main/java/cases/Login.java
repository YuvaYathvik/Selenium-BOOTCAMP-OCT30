package cases;

import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.IndividualPage;
import Pages.LoginPage;

public class Login extends ProjectSpecifiedMethod{
	

//	  @BeforeTest
//	public void setfile () 
//	excelFileName = "Credentials";
	
	
//	(dataProvider = "fetchData")
	@Test 
	public void runLogin() throws InterruptedException {
		LoginPage run = new LoginPage();
		
		
		 run.EnterUserName()
		.EnterPassword()
		.clickLoginButton();
		
		
		
		
		
	}
}
