package cases;

public class EditWorkTypeGroup {

	
	public void runEditWorkTypeGroup () {
		
		
	}
}
