package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class VerifyDashboardSubscribe extends ProjectSpecifiedMethod{


		@Test
		public void runVerifyDashboardSubscribe () throws InterruptedException {
			
			new LoginPage()
			.EnterUserName()
			.EnterPassword()
			.clickLoginButton()
			.clicktongglebutton()
			.clickviewall()
			.SelectDashboardsFromAPPLauncher()
			.SearchRecentDashboards()
			.clickDropDown()
			.SelectSubscribe()
			.SeleckDaily()
			.ClickSave()
			.VerifySubscribe();
	}

}
