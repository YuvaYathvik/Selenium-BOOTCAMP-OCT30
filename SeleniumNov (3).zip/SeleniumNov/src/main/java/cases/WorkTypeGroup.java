package cases;

import org.testng.annotations.Test;

import Base.ProjectSpecifiedMethod;
import Pages.LoginPage;

public class WorkTypeGroup extends ProjectSpecifiedMethod{
	
	@Test
	public void runWorkTypeGroup () throws InterruptedException {
		
		new LoginPage()
		.EnterUserName()
		.EnterPassword()
		.clickLoginButton()
		.clicktongglebutton()
		.clickviewall()
		.ClickWorkTypeGroupFromAppLauncher()
		.SearchWorkTypeGroupByYourName()
		.ClickDropDown()
		.ClickEdit()
		.EnterDiscription()
		.select()
		.GroupTypeAsCapacity()
		.ClickOnSave()
		.ClickOnSalesforceAutomation()
		.VerifyDescriptionAutomation();
		
		
		
	}

}
